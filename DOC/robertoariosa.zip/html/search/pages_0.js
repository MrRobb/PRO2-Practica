var searchData=
[
  ['práctica_20de_20pro2_3a_20_20experimentos_20genéticos_20de_20laboratorio_2e',['Práctica de PRO2:  Experimentos genéticos de laboratorio.',['../index.html',1,'']]]
];
