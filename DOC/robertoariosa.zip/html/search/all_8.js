var searchData=
[
  ['tiene_5fascendientes',['tiene_ascendientes',['../class_individuo.html#ac30b51c4b8268e4e2cd0f3ac77f20b07',1,'Individuo']]]
];
