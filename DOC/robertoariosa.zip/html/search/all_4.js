var searchData=
[
  ['leer',['leer',['../class_cromosoma.html#abf3ef15e3f9af661572a768029e9c959',1,'Cromosoma::leer()'],['../class_especie.html#a2335c9ddc4757e964d78e6267304cf52',1,'Especie::leer()'],['../class_individuo.html#aca2828dea808d8a09b6bc22719dca574',1,'Individuo::leer()'],['../class_poblacion.html#a94a32410a0d2b2066b0d7203efbf673f',1,'Poblacion::leer()']]]
];
