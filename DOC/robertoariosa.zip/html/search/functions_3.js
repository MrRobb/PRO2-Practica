var searchData=
[
  ['individuo',['Individuo',['../class_individuo.html#a3042a660b9789ee24dd3658248c8e0b9',1,'Individuo::Individuo()'],['../class_individuo.html#aa4e303d7179a1ad0f0f2986d093d830a',1,'Individuo::Individuo(string nombre, const Individuo &amp;madre, const Individuo &amp;padre, const Especie &amp;esp)']]]
];
