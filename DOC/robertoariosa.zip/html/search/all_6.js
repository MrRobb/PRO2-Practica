var searchData=
[
  ['práctica_20de_20pro2_3a_20_20experimentos_20genéticos_20de_20laboratorio_2e',['Práctica de PRO2:  Experimentos genéticos de laboratorio.',['../index.html',1,'']]],
  ['poblacion',['Poblacion',['../class_poblacion.html',1,'Poblacion'],['../class_poblacion.html#ad3909b6ea27344b861b7cd548cb2b65e',1,'Poblacion::Poblacion()']]],
  ['poblacion_2ehh',['Poblacion.hh',['../_poblacion_8hh.html',1,'']]],
  ['pro2_2ecc',['pro2.cc',['../pro2_8cc.html',1,'']]]
];
