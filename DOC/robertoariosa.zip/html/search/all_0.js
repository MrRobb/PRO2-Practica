var searchData=
[
  ['anadir_5findividuo',['anadir_individuo',['../class_poblacion.html#a4622ccceef105548460351376791f8f6',1,'Poblacion']]]
];
