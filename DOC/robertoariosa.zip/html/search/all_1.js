var searchData=
[
  ['completar_5farbol_5fgenealogico',['completar_arbol_genealogico',['../class_poblacion.html#a2dd7bd82d100852ad3767d5830fe932a',1,'Poblacion']]],
  ['consultar_5fes_5fmasculino',['consultar_es_masculino',['../class_individuo.html#a40c32d5439ebad9b120c582bf172d116',1,'Individuo']]],
  ['consultar_5flongitud_5fcromosoma_5fnormal',['consultar_longitud_cromosoma_normal',['../class_especie.html#a2b45f904d78a40980e4e5416b2114c28',1,'Especie']]],
  ['consultar_5flongitud_5fcromosoma_5fx',['consultar_longitud_cromosoma_x',['../class_especie.html#a38523cc3b55bb9d5764dddabc22c7da2',1,'Especie']]],
  ['consultar_5flongitud_5fcromosoma_5fy',['consultar_longitud_cromosoma_y',['../class_especie.html#a52aba18b3261338808cd78c92ba4388e',1,'Especie']]],
  ['consultar_5fmadre',['consultar_madre',['../class_individuo.html#a9de458f5ab162422902d067d717eb5d7',1,'Individuo']]],
  ['consultar_5fnombre',['consultar_nombre',['../class_individuo.html#a0256784d237c97bdbd515bebc1d75574',1,'Individuo']]],
  ['consultar_5fpadre',['consultar_padre',['../class_individuo.html#a255f1cc78dd6c3c079f90b165c8fc1d2',1,'Individuo']]],
  ['consultar_5fpares_5fcromosomas',['consultar_pares_cromosomas',['../class_especie.html#a94666f2f2ff0dcfe29e2065eabdce213',1,'Especie']]],
  ['cromosoma',['Cromosoma',['../class_cromosoma.html',1,'Cromosoma'],['../class_cromosoma.html#a8367f3dd60c6af083aed533c69f17b29',1,'Cromosoma::Cromosoma()'],['../class_cromosoma.html#a846b63ce7e4c4db0060336afd62a4d20',1,'Cromosoma::Cromosoma(int li)']]],
  ['cromosoma_2ehh',['Cromosoma.hh',['../_cromosoma_8hh.html',1,'']]],
  ['cruzamiento_5fnormales',['cruzamiento_normales',['../class_cromosoma.html#a18ee9f62a268890626c3bef450a1af54',1,'Cromosoma']]],
  ['cruzamiento_5fsexuales',['cruzamiento_sexuales',['../class_cromosoma.html#ac3f049c73703bdf492cfa8e0daa86d48',1,'Cromosoma']]]
];
